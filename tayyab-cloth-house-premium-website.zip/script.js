// ================================================
// EDITABLE BUSINESS SETTINGS
// Change these values to update phone / WhatsApp.
// ================================================
const BUSINESS = {
  name: "Tayyab Cloth House",
  whatsapp: "923134544773",
  phone: "+923134544773",
  mapsUrl: "https://maps.app.goo.gl/XLKEAKYvCKXLLrkC6"
};

// WhatsApp deep links with service-specific pre-filled messages
document.querySelectorAll(".whatsapp-link").forEach(link => {
  const message = link.dataset.message || `Hello ${BUSINESS.name}, I'd like to make an enquiry.`;
  link.href = `https://wa.me/${BUSINESS.whatsapp}?text=${encodeURIComponent(message)}`;
  link.target = "_blank";
  link.rel = "noopener";
});

// Current year
document.getElementById("year").textContent = new Date().getFullYear();

// Highlight today's opening hours
const dayName = new Intl.DateTimeFormat("en-US", { weekday: "long" }).format(new Date());
document.querySelectorAll(".hour-row").forEach(row => {
  if (row.dataset.day === dayName) row.classList.add("current");
});

// Sticky header
const header = document.querySelector(".site-header");
const setHeader = () => header.classList.toggle("scrolled", window.scrollY > 50);
setHeader();
window.addEventListener("scroll", setHeader, { passive: true });

// Mobile navigation
const menuButton = document.querySelector(".menu-toggle");
const nav = document.querySelector(".nav-links");
menuButton.addEventListener("click", () => {
  const open = nav.classList.toggle("open");
  menuButton.classList.toggle("active", open);
  menuButton.setAttribute("aria-expanded", String(open));
  document.body.classList.toggle("menu-open", open);
});
nav.querySelectorAll("a").forEach(a => a.addEventListener("click", () => {
  nav.classList.remove("open");
  menuButton.classList.remove("active");
  menuButton.setAttribute("aria-expanded", "false");
  document.body.classList.remove("menu-open");
}));

// Reveal on scroll
const revealObserver = new IntersectionObserver(entries => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.classList.add("visible");
      revealObserver.unobserve(entry.target);
    }
  });
}, { threshold: 0.12 });

document.querySelectorAll(".reveal").forEach((el, i) => {
  el.style.transitionDelay = `${Math.min(i % 4, 3) * 70}ms`;
  revealObserver.observe(el);
});

// Subtle cursor ambience on desktop
const glow = document.querySelector(".cursor-glow");
window.addEventListener("pointermove", e => {
  glow.style.left = `${e.clientX}px`;
  glow.style.top = `${e.clientY}px`;
}, { passive: true });
