TAYYAB CLOTH HOUSE WEBSITE
==========================

Files:
- index.html
- styles.css
- script.js

How to use:
1. Extract the ZIP.
2. Open index.html in a browser.
3. Upload all three files to your hosting/server in the same folder.

Easy edits:
- Business phone / WhatsApp: edit the BUSINESS object at the top of script.js.
- Text and sections: edit index.html.
- Colors: edit the CSS variables at the top of styles.css.
- Images: replace the image URLs in index.html and the hero image URL in styles.css.
- Google Map: replace the iframe URL in index.html if the location changes.

Current listing details used:
Tayyab Cloth House
23 Ichra Rd, Ichhra Shah Din Scheme, Lahore 54000
Phone: +92 313 4544773

Opening hours used:
Mon 11:00 AM–9:00 PM
Tue 11:00 AM–9:00 PM
Wed 11:00 AM–9:00 PM
Thu 11:00 AM–9:00 PM
Fri 11:00 AM–9:00 PM
Sat 12:00 PM–8:00 PM
Sun 11:00 AM–9:00 PM

Note:
Gallery imagery is presentation/editorial imagery from Unsplash and is not claimed
to show the actual store or its stock. Replace it with original business photography
whenever available.
